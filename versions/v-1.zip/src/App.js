import React from "react";
import HeaderNav from "./components/header/Header";
import Banner from './components/banner/Banner'
import Services from './components/service/Services'



function App() {

  return ( 
<>
  
  <HeaderNav />
  <Banner />
  <Services />

</>
  
  )
}

export default App;
